package com.postbook;

import java.net.URI;
import java.sql.SQLException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.model.User;
import dao.Userdao;
import dao.Userdaoimpl;

@Path("twitter")
public class MyResource {

	private Userdao userDao = new Userdaoimpl();

	@POST
	@Path("/user/add")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void addUser(User user) throws Exception {
		userDao.signup(user);

	}

	@Path("user/login")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response loginUser(User user) throws Exception {
		try {
		if(userDao.signin(user) != null) {
			return Response.status(Response.Status.OK).entity("success").build();
		}
			else {
				return Response.status(Response.Status.UNAUTHORIZED).entity("Invalid cradentials").build();
			}
					
			}
		catch(Exception e){
		
		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error in login").build();
		
	
	}
	}
}


