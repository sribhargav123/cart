package dao;

import com.model.Product;

public interface Productdao {
	Product viewall(Product product)throws Exception;

}
