package dao;
import com.model.*;

import java.sql.*;
public class Userdaoimpl implements Userdao{
  private Connection connection;
  public Userdaoimpl()
  {
	  connection=Dbconnect.getConnection();
  }
@Override
public User signin(User user) throws Exception {
	// TODO Auto-generated method stub
	String si="Select *from EUSER where USER_EMAIL=? and USER_PWD=?";
	PreparedStatement pst=connection.prepareStatement(si);
	
	pst.setString(1, user.getUser_email());
	pst.setString(2, user.getUser_pwd());
	ResultSet rs=pst.executeQuery();
	if(rs.next())
	{
		if(rs.getString("USER_PWD").equals(user.getUser_pwd()))
			return user;
		else
			return null;
	}
	return null;
	
}
@Override
public User signup(User user) throws Exception {
	// TODO Auto-generated method stub
	String sql="Insert into euser (USER_NAME,USER_EMAIL,USER_PWD) values(?,?,?)";
	PreparedStatement pst= connection.prepareStatement(sql);
	System.out.println(user.getUser_email()+user.getUser_name()+user.getUser_pwd());
	pst.setString(1, user.getUser_name());
	pst.setString(2, user.getUser_email());
	pst.setString(3, user.getUser_pwd());
	pst.executeUpdate();
	return user;
	
}
@Override
public User viewprofile(User user) throws Exception {
	// TODO Auto-generated method stub
	String sql="Select *from euser where id=?";
	PreparedStatement pst=connection.prepareStatement(sql);
	pst.setInt(1, user.getId());
	
	pst.executeUpdate();
	return user;
}
  

}
