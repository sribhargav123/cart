package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Product;

public class Productdaoimpl implements Productdao {
	private Connection connection;
	Productdaoimpl (){
		connection=Dbconnect.getConnection();
	}
	
	@Override
	public Product viewall(Product product) throws SQLException {
		String st="select * from Products where p_id=?";
		PreparedStatement pst=connection.prepareStatement(st);
		pst.setInt(1,product.getP_id());
		ResultSet rs=pst.executeQuery();
		return product;
	}

	
}
