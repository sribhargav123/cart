

function signin() {
	var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    console.log("Submitting form with email:", email, "password:", password);

    var user = {
        user_email: email,
        user_pwd: password
    };

    fetch('http://localhost:8080/postbook/webapi/twitter/user/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(user)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
     
        window.location.href = 'http://localhost:8080/postbook/home.html';
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
        alert('Failed to Login');
    })
};

function logout() {
 
   document.getElementById('signin').style.display = 'block';
   document.getElementById('logout').style.display = 'none';
}
