function submitForm() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    console.log("Submitting form with name:", name, "email:", email, "password:", password);

    var user = {
        name: name,
        email: email,
        password: password
    };

    fetch("http://localhost:8080/postbook/webapi/main/user/add", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(user)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        // handle success
        alert('User added successfully');
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
        alert('Failed to add user');
    });
}
