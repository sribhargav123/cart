package dao;
import java.sql.*;
import com.User;
public interface Userdao {
User signin(User user) throws Exception;
User signup(User user) throws Exception;
User viewprofile(User user) throws Exception;
}
