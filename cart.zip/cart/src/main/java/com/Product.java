package com;

public class Product {

}
